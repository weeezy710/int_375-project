import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
df=pd.read_csv(r'C:\Users\ar941\Downloads\Flight_Price_Dataset_of_Bangladesh.csv')
df.head()
df["Departure Date & Time"] = pd.to_datetime(df["Departure Date & Time"], errors='coerce')
df = df.dropna(subset=["Departure Date & Time", "Total Fare (BDT)"])
def get_time_of_day(hour):
    if 5 <= hour < 12:
        return "Morning"
    elif 12 <= hour < 17:
        return "Afternoon"
    elif 17 <= hour < 21:
        return "Evening"
    else:
        return "Night"
df["Time of Day"] = df["Departure Date & Time"].dt.hour.apply(get_time_of_day)
time_of_day_fare = df.groupby("Time of Day")["Total Fare (BDT)"].mean().sort_values()
plt.figure(figsize=(8, 5))
plt.bar(time_of_day_fare.index, time_of_day_fare.values, color="skyblue", edgecolor="black")
plt.title("Average Flight Fare by Time of Day")
plt.xlabel("Time of Day")
plt.ylabel("Average Fare (BDT)")
plt.grid(axis="y")
plt.tight_layout()
plt.savefig("Flight_Fare_By_Time_of_Day.png")
plt.show()
